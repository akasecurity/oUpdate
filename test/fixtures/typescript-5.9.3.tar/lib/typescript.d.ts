    interface SourceFileLike {
        readonly text: string;
    }
    interface SourceFileLike {
