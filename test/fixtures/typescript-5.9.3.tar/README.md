// trimmed fixture
