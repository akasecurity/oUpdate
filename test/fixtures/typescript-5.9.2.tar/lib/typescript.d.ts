    interface SourceFileLike {
        readonly text: string;
        languageVariant?: LanguageVariant;
    }
    interface SourceFileLike {
